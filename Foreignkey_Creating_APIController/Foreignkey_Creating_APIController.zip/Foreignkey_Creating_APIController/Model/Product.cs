﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Foreignkey_Creating_APIController.Model
{
    public class Product
    {
        [Key]
        public int Id { get; set; }

        public string? ProductName { get; set; }

        public int productPrice { get; set; }
       // [JsonIgnore]
       // public virtual List<CustomerProduct>? CustomerProduct { get; set; }

    }
}
