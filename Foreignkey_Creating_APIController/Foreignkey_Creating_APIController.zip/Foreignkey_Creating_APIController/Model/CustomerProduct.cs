﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Foreignkey_Creating_APIController.Model
{
    public class CustomerProduct
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("CustomerId")]
        public int CustomerId { get; set; }
       
        [ForeignKey("ProductId")]
        public int ProductId { get; set; }
       
        public virtual List<Product>? Products { get; set; }
        public virtual List<Customer>? customer { get; set; }
    }
}
